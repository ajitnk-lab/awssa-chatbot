import json
import os
import logging
from typing import Dict, Any, List
import boto3
from strands_agents import Agent, retrieve

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
bedrock_runtime = boto3.client('bedrock-runtime', region_name=os.environ.get('REGION', 'us-west-2'))
bedrock_agent_runtime = boto3.client('bedrock-agent-runtime', region_name=os.environ.get('REGION', 'us-west-2'))

# Configuration
KNOWLEDGE_BASE_ID = os.environ.get('KNOWLEDGE_BASE_ID')
MODEL_ID = os.environ.get('MODEL_ID', 'anthropic.claude-3-haiku-20240307-v1:0')

# System prompt for the Solutions Architect Agent
SYSTEM_PROMPT = """You are an AWS Solutions Architect Agent specializing in helping customers find the right AWS sample projects and repositories for their specific needs.

Your expertise includes:
- Deep knowledge of 925+ AWS sample repositories from aws-samples and awslabs
- Understanding of AWS services, architectures, and best practices
- Ability to match customer requirements with appropriate sample projects
- Knowledge of deployment complexity, costs, and technical requirements

When a customer asks for help:

1. **Understand Requirements**: Ask clarifying questions about:
   - Use case and business problem
   - Preferred programming language
   - AWS services they want to use
   - Technical complexity level
   - Budget constraints
   - Timeline requirements

2. **Search and Recommend**: Use the retrieve tool to find relevant repositories and provide:
   - 2-3 most relevant sample projects
   - Brief description of each project
   - GitHub URL for each recommendation
   - Why each project fits their needs
   - Setup time and cost estimates
   - Prerequisites and technical requirements

3. **Provide Context**: For each recommendation, explain:
   - What AWS services it uses
   - What problem it solves
   - How complex it is to deploy
   - Any limitations or considerations

4. **Follow Up**: Offer to help with:
   - More specific recommendations
   - Architecture questions
   - Deployment guidance
   - Alternative approaches

Always be helpful, concise, and focus on practical solutions. Include GitHub URLs in your responses so customers can easily access the repositories.

Remember: You have access to detailed metadata about each repository including stars, languages, AWS services, setup time, cost estimates, and more."""

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for the AWS Solutions Architect Agent.
    Processes chat requests and returns agent responses.
    """
    try:
        # Handle CORS preflight
        if event.get('httpMethod') == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'POST, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type'
                },
                'body': ''
            }
        
        # Parse request body
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event.get('body', {})
        
        message = body.get('message', '')
        session_id = body.get('session_id', 'default')
        
        if not message:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'POST, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type'
                },
                'body': json.dumps({'error': 'Message is required'})
            }
        
        logger.info(f"Processing message: {message[:100]}...")
        
        # Check if Knowledge Base is available
        if not KNOWLEDGE_BASE_ID or KNOWLEDGE_BASE_ID == 'PLACEHOLDER':
            # Fallback response without Knowledge Base
            response = f"""I understand you're looking for help with: "{message}"

As an AWS Solutions Architect Agent, I can help you find the right AWS sample projects. Here are some recommendations based on common patterns:

**For Serverless APIs:**
- aws-samples/serverless-api-gateway-lambda
  - Perfect for REST APIs with Lambda
  - Uses: API Gateway, Lambda, DynamoDB
  - Language: Python/Node.js
  - Setup: < 1 hour

**For Data Processing:**
- awslabs/amazon-kinesis-data-generator
  - Great for streaming data scenarios
  - Uses: Kinesis, Lambda, S3
  - Real-time processing capabilities

**For Web Applications:**
- aws-samples/aws-amplify-react-template
  - Full-stack web app template
  - Uses: Amplify, Cognito, AppSync
  - Frontend: React

**For Machine Learning:**
- aws-samples/amazon-sagemaker-examples
  - Comprehensive ML examples
  - Uses: SageMaker, S3, Lambda
  - Various ML use cases

Note: The Knowledge Base is being configured to provide more accurate, data-driven recommendations based on your specific requirements. Once available, I'll be able to search through 925+ AWS sample repositories to find the perfect match for your needs.

Would you like me to help you with any specific AWS service or use case?"""
        else:
            # Initialize Strands Agent with retrieve tool
            agent = Agent(
                model_id=MODEL_ID,
                system_prompt=SYSTEM_PROMPT,
                tools=[
                    retrieve(
                        knowledge_base_id=KNOWLEDGE_BASE_ID,
                        model_id=MODEL_ID,
                        region=os.environ.get('REGION', 'us-west-2')
                    )
                ],
                session_id=session_id
            )
            
            # Get agent response
            response = agent.run(message)
        
        logger.info(f"Agent response generated successfully")
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps({
                'response': response,
                'session_id': session_id
            })
        }
        
    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'message': str(e)
            })
        }
